<?php
namespace StockTransfer\Models;

use Plenty\Modules\StockManagement\Stock\Models\Stock;

/**
 * Created by ptopczewski, 01.07.17 14:39
 * Class StockData
 * @package StockTransfer\Models
 */
class StockData implements \JsonSerializable
{
    /**
     * @var string
     */
    private $name1 = '';

    /**
     * @var string
     */
    private $name2 = '';

    /**
     * @var string
     */
    private $name3 = '';

    /**
     * @var bool
     */
    private $isSelected = false;

    /**
     * @var string
     */
    private $number = '';

    /**
     * @var int
     */
    private $sourceStockNet = 0;

    /**
     * @var int
     */
    private $requiredStock = 0;

    /**
     * @var Stock
     */
    private $stock;

    /**
     * StockData constructor.
     * @param Stock $stock
     */
    public function __construct(Stock $stock)
    {
        $this->stock = $stock;
    }

    /**
     * @return string
     */
    public function getName1(): string
    {
        return $this->name1;
    }

    /**
     * @param string $name1
     * @return $this
     */
    public function setName1($name1)
    {
        $this->name1 = $name1;
        return $this;
    }

    /**
     * @return string
     */
    public function getName2(): string
    {
        return $this->name2;
    }

    /**
     * @param string $name2
     * @return $this
     */
    public function setName2($name2)
    {
        $this->name2 = $name2;
        return $this;
    }

    /**
     * @return string
     */
    public function getName3(): string
    {
        return $this->name3;
    }

    /**
     * @param string $name3
     * @return $this
     */
    public function setName3($name3)
    {
        $this->name3 = $name3;
        return $this;
    }

    /**
     * @return bool
     */
    public function isSelected(): bool
    {
        return $this->isSelected;
    }

    /**
     * @param bool $isSelected
     * @return $this
     */
    public function setSelected($isSelected)
    {
        $this->isSelected = $isSelected;
        return $this;
    }

    /**
     * @return string
     */
    public function getNumber(): string
    {
        return $this->number;
    }

    /**
     * @param string $number
     * @return $this
     */
    public function setNumber($number)
    {
        $this->number = $number;
        return $this;
    }

    /**
     * @return int
     */
    public function getSourceStockNet(): int
    {
        return $this->sourceStockNet;
    }

    /**
     * @param int $sourceStockNet
     * @return $this
     */
    public function setSourceStockNet($sourceStockNet)
    {
        $this->sourceStockNet = $sourceStockNet;
        return $this;
    }

    /**
     * @return int
     */
    public function getRequiredStock(): int
    {
        return $this->requiredStock;
    }

    /**
     * @param int $requiredStock
     * @return $this
     */
    public function setRequiredStock($requiredStock)
    {
        $this->requiredStock = $requiredStock;
        return $this;
    }

    /**
     * Specify data which should be serialized to JSON
     * @link http://php.net/manual/en/jsonserializable.jsonserialize.php
     * @return mixed data which can be serialized by <b>json_encode</b>,
     * which is a value of any type other than a resource.
     * @since 5.4.0
     */
    function jsonSerialize()
    {
        $data = $this->stock->toArray();
        return array_merge(
            $data,
            [
                'name1' => $this->getName1(),
                'name2' => $this->getName2(),
                'name3' => $this->getName3(),
                'isSelected' => $this->isSelected(),
                'number' => $this->getNumber(),
                'sourceStockNet' => $this->getSourceStockNet(),
                'requiredStock' => $this->getRequiredStock(),
            ]
        );
    }
}