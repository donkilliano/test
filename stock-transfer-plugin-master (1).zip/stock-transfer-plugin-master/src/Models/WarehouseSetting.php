<?php
namespace StockTransfer\Models;

use Plenty\Modules\Plugin\DataBase\Contracts\Model;

/**
 * Created by ptopczewski, 26.07.17 22:07
 * Class WarehouseSetting
 * @package StockTransfer\Models
 *
 * @property int $warehouseId
 * @property array $settings
 */
class WarehouseSetting extends Model
{
    public $warehouseId = 0;

    public $settings = [];

    protected $primaryKeyFieldName = 'warehouseId';
    protected $autoIncrementPrimaryKey = false;

    public function getTableName(): string
    {
        return 'StockTransfer::warehouse';
    }
}