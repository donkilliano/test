<?php
namespace StockTransfer\Contracts;

use Plenty\Repositories\Models\PaginatedResult;
use StockTransfer\Models\StockData;

/**
 * Created by ptopczewski, 01.07.17 14:47
 * Interface StockTransferRepositoryContract
 * @package StockTransfer\Contracts
 */
interface StockTransferRepositoryContract
{
    /**
     * @param int $targetWarehouseId
     * @param int $sourceWarehouseId
     * @param int $page
     * @param int $itemsPerPage
     *
     * @return PaginatedResult
     */
    public function getDefaultStockItems($targetWarehouseId, $sourceWarehouseId, $page, $itemsPerPage);

    /**
     * @param int $targetWarehouseId
     * @param int $sourceWarehouseId
     * @param string $search
     * @param int $page
     * @param int $itemsPerPage
     * @return PaginatedResult
     */
    public function searchStockItems($targetWarehouseId, $sourceWarehouseId, $search, $page, $itemsPerPage);

    /**
     * @param int $targetWarehouseId
     * @param int $sourceWarehouseId
     * @param StockData[] $stockDataItems
     */
    public function createOrder($targetWarehouseId, $sourceWarehouseId, $stockDataItems);

    /**
     * @param int $targetWarehouseId
     * @param int $page
     * @param int $itemsPerPage
     * @return PaginatedResult
     */
    public function searchOrders($targetWarehouseId, $page, $itemsPerPage);

    /**
     * @param int $orderId
     */
    public function intake($orderId);
}