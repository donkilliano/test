<?php
namespace StockTransfer\Migrations;

use Plenty\Modules\Plugin\DataBase\Contracts\Migrate;
use StockTransfer\Models\WarehouseSetting;

/**
 * Created by ptopczewski, 26.07.17 22:10
 * Class CreateWarehouseSettings
 * @package StockTransfer\Migrations
 */
class CreateWarehouseSettings
{
    /**
     * @param Migrate $migrate
     */
    public function run(Migrate $migrate)
    {
        try {
            $migrate->deleteTable(WarehouseSetting::class);
        } catch (\Exception $e) {
            //Table does not exist
        }
        $migrate->createTable(WarehouseSetting::class);
    }
}