<?php
namespace StockTransfer\Helper;

/**
 * Created by ptopczewski, 28.07.17 16:09
 * Class ClearCriteria
 * @package StockTransfer\Helper
 */
interface ClearCriteria
{
}