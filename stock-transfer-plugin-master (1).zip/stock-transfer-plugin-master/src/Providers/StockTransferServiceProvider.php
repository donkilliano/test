<?php
namespace StockTransfer\Providers;

use Plenty\Plugin\ServiceProvider;
use StockTransfer\Contracts\StockTransferRepositoryContract;
use StockTransfer\Repositories\StockTransferRepository;

/**
 * Created by ptopczewski, 15.06.17 09:52
 * Class StockTransferServiceProvider
 * @package StockTransfer\Providers
 */
class StockTransferServiceProvider extends ServiceProvider
{
    /**
     *
     */
    public function register(){
        $this->getApplication()->register(StockTransferRouteServiceProvider::class);
        $this->getApplication()->singleton(StockTransferRepositoryContract::class, StockTransferRepository::class);
    }
}