<?php
namespace StockTransfer\Providers;

use Plenty\Modules\Plugin\Libs\Contracts\LibraryCallContract;
use Plenty\Plugin\RouteServiceProvider;
use Plenty\Plugin\Routing\ApiRouter;
use Plenty\Plugin\Routing\Router;
use StockTransfer\Controller\SettingsController;
use StockTransfer\Controller\StockController;

/**
 * Created by ptopczewski, 18.06.17 07:49
 * Class StockTransferRouteServiceProvider
 * @package StockTransfer\Providers
 */
class StockTransferRouteServiceProvider extends RouteServiceProvider
{
    public function map(ApiRouter $apiRouter, Router $router){

        $apiRouter->version(['v1'], ['middleware' => 'oauth'], function($apiRouter){
            $apiRouter->get('stock_transfer/variations', ['uses' => StockController::class.'@getVariationStock']);
            $apiRouter->get('stock_transfer/search_orders', ['uses' => StockController::class.'@searchOrders']);
            $apiRouter->post('stock_transfer/create', ['uses' => StockController::class.'@createOrder']);
            $apiRouter->post('stock_transfer/intake/{orderId}', ['uses' => StockController::class.'@intake']);

            $apiRouter->get('stock_transfer/settings', ['uses' => SettingsController::class.'@getWarehouseSettings']);
            $apiRouter->post('stock_transfer/settings/{warehouseId}', ['uses' => SettingsController::class.'@saveWarehouseSettings']);
        });

        $router->get('testest', function(){
            /** @var LibraryCallContract $libCall */
            $libCall = pluginApp(LibraryCallContract::class);

            return $libCall->call('StockTransfer::test', ['foobar']);
        });
    }
}