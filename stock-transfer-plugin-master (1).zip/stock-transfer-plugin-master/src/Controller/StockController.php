<?php
namespace StockTransfer\Controller;

use Plenty\Modules\Account\Address\Contracts\AddressRepositoryContract;
use Plenty\Modules\Account\Address\Models\AddressRelationType;
use Plenty\Plugin\ConfigRepository;
use Plenty\Plugin\Controller;
use Plenty\Plugin\Http\Request;
use Plenty\Repositories\Models\PaginatedResult;
use StockTransfer\Contracts\StockTransferRepositoryContract;

/**
 * Class StockController
 * @package StockTransfer\Controller
 */
class StockController extends Controller
{
    /**
     * @param Request $request
     * @param StockTransferRepositoryContract $stockRepository
     * @return PaginatedResult
     */
    public function getVariationStock(Request $request, StockTransferRepositoryContract $stockRepository)
    {
        if (!$request->get('searchString', false)) {
            return $stockRepository->getDefaultStockItems(
                (INT)$request->get('warehouseId'),
                (INT)$request->get('sourceWarehouseId'),
                $request->get('page', 1),
                $request->get('itemsPerPage', 25)
            );
        } else {
            return $stockRepository->searchStockItems(
                (INT)$request->get('warehouseId'),
                (INT)$request->get('sourceWarehouseId'),
                $request->get('searchString'),
                $request->get('page', 1),
                $request->get('itemsPerPage', 25)
            );
        }
    }

    /**
     * @param Request $request
     * @param StockTransferRepositoryContract $stockTransferRepository
     * @return mixed
     */
    public function createOrder(Request $request, StockTransferRepositoryContract $stockTransferRepository)
    {
        return $stockTransferRepository->createOrder(
            (INT)$request->get('warehouseId'),
            (INT)$request->get('sourceWarehouseId'),
            json_decode($request->getContent(), true)
        );
    }

    /**
     * @param $orderId
     * @param StockTransferRepositoryContract $stockTransferRepository
     * @return
     * @internal param Request $request
     */
    public function intake($orderId, StockTransferRepositoryContract $stockTransferRepository)
    {
        return $stockTransferRepository->intake($orderId);
    }


    /**
     * @param Request $request
     * @param StockTransferRepositoryContract $stockTransferRepository
     * @return mixed
     */
    public function searchOrders(Request $request, StockTransferRepositoryContract $stockTransferRepository)
    {
        return $stockTransferRepository->searchOrders(
            (INT)$request->get('warehouseId'),
            $request->get('page', 1),
            $request->get('itemsPerPage', 25)
        );
    }
}