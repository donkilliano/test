<?php
namespace StockTransfer\Controller;

use Plenty\Modules\Account\Address\Models\AddressRelationType;
use Plenty\Modules\Account\Contact\Contracts\ContactAddressRepositoryContract;
use Plenty\Modules\Plugin\DataBase\Contracts\DataBase;
use Plenty\Modules\StockManagement\Warehouse\Contracts\WarehouseRepositoryContract;
use Plenty\Modules\StockManagement\Warehouse\Models\Warehouse;
use Plenty\Plugin\Controller;
use Plenty\Plugin\Http\Request;
use StockTransfer\Models\WarehouseSetting;

/**
 * Created by ptopczewski, 25.07.17 16:56
 * Class SettingsController
 * @package StockTransfer\Controller
 */
class SettingsController extends Controller
{
    private $database = null;

    /**
     * SettingsController constructor.
     * @param DataBase $dataBase
     */
    public function __construct(DataBase $dataBase)
    {
        $this->database = $dataBase;
    }

    /**
     * @return array
     */
    public function getWarehouseSettings()
    {
        $result                = [];
        $warehouseSettingsList = $this->database->query(WarehouseSetting::class)->get();

        /** @var ContactAddressRepositoryContract $contactAddressRepository */
        $contactAddressRepository = pluginApp(ContactAddressRepositoryContract::class);

        /** @var WarehouseRepositoryContract $warehouseRepo */
        $warehouseRepo = pluginApp(WarehouseRepositoryContract::class);

        $warehouseList = $warehouseRepo->all();
        foreach ($warehouseList as $warehouse) {
            if ($warehouse instanceof Warehouse) {

                $response = [
                    'warehouse' => $warehouse,
                    'settings' => null,
                    'address' => null
                ];

                foreach ($warehouseSettingsList as $warehouseSettings) {
                    if ($warehouseSettings instanceof WarehouseSetting && $warehouse->id == $warehouseSettings->warehouseId) {

                        $response['settings'] = $warehouseSettings->settings;

                        if (array_key_exists('contactId', $warehouseSettings->settings)) {
                            $contactId = $warehouseSettings->settings['contactId'];

                            try{
                                $address = $contactAddressRepository->findContactAddressByTypeId(
                                    $contactId,
                                    AddressRelationType::BILLING_ADDRESS,
                                    true
                                );
                                $response['address'] = $address;
                            }catch(\Exception $exc){

                            }

                        }
                    }
                }

                $result[] = $response;
            }
        }
        return $result;
    }

    /**
     * @param $warehouseId
     * @param Request $request
     * @return array
     */
    public function saveWarehouseSettings($warehouseId, Request $request)
    {
        $warehouseSetting = $this->database->find(WarehouseSetting::class, $warehouseId);

        if (!$warehouseSetting instanceof WarehouseSetting) {
            /** @var WarehouseSetting $warehouseSetting */
            $warehouseSetting = pluginApp(WarehouseSetting::class);
            $warehouseSetting->warehouseId = (INT)$warehouseId;
        }

        $warehouseSetting->settings = $request->all();

        $this->database->save($warehouseSetting);
        return [true];
    }
}