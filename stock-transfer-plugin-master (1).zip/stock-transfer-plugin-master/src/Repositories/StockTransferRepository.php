<?php
namespace StockTransfer\Repositories;

use Plenty\Modules\Account\Address\Models\Address;
use Plenty\Modules\Account\Address\Models\AddressRelationType;
use Plenty\Modules\Account\Contact\Contracts\ContactAddressRepositoryContract;
use Plenty\Modules\Cloud\ElasticSearch\Lib\ElasticSearch;
use Plenty\Modules\Cloud\ElasticSearch\Lib\Processor\DocumentProcessor;
use Plenty\Modules\Cloud\ElasticSearch\Lib\Search\Document\DocumentSearch;
use Plenty\Modules\Cloud\ElasticSearch\Lib\Source\IncludeSource;
use Plenty\Modules\Cloud\ElasticSearch\Lib\Source\Mutator\BuiltIn\LanguageMutator;
use Plenty\Modules\Item\Search\Contracts\VariationElasticSearchSearchRepositoryContract;
use Plenty\Modules\Item\Search\Filter\SearchFilter;
use Plenty\Modules\Item\Search\Filter\VariationBaseFilter;
use Plenty\Modules\Order\Contracts\OrderRepositoryContract;
use Plenty\Modules\Order\Models\OrderItem;
use Plenty\Modules\Order\Models\OrderItemType;
use Plenty\Modules\Order\Models\OrderType;
use Plenty\Modules\Order\Property\Models\OrderPropertyType;
use Plenty\Modules\Order\RelationReference\Models\OrderRelationReference;
use Plenty\Modules\Plugin\DataBase\Contracts\DataBase;
use Plenty\Modules\StockManagement\Stock\Contracts\StockRepositoryContract;
use Plenty\Modules\StockManagement\Stock\Models\Stock;
use Plenty\Plugin\Application;
use Plenty\Plugin\ConfigRepository;
use Plenty\Repositories\Models\PaginatedResult;
use StockTransfer\Contracts\StockTransferRepositoryContract;
use StockTransfer\Models\StockData;
use StockTransfer\Models\WarehouseSetting;

/**
 * Created by ptopczewski, 01.07.17 14:53
 * Class StockTransferRepository
 * @package StockTransfer\Repositories
 */
class StockTransferRepository implements StockTransferRepositoryContract
{
    /**
     * @var StockRepositoryContract
     */
    private $stockRepository;
    /**
     * @var Application
     */
    private $application;
    /**
     * @var ConfigRepository
     */
    private $configRepository;

    /**
     * StockTransferRepository constructor.
     * @param StockRepositoryContract $stockRepository
     * @param Application $application
     * @param ConfigRepository $configRepository
     */
    public function __construct(StockRepositoryContract $stockRepository, Application $application, ConfigRepository $configRepository)
    {
        $this->stockRepository  = $stockRepository;
        $this->application      = $application;
        $this->configRepository = $configRepository;
    }

    /**
     * @param int $targetWarehouseId
     * @param int $sourceWarehouseId
     * @param int $page
     * @param int $itemsPerPage
     *
     * @return PaginatedResult|array
     */
    public function getDefaultStockItems($targetWarehouseId, $sourceWarehouseId, $page, $itemsPerPage)
    {
        //load stock items for stock transfer
        $this->stockRepository->clearFilters();
        $this->stockRepository->clearCriteria();
        $this->stockRepository->setFilters(
            [
                'warehouseId' => $targetWarehouseId,
                'reorderDelta' => 0
            ]
        );

        try {
            $stockList = $this->stockRepository->listStock(
                ['*'],
                $page,
                $itemsPerPage
            );

            $variationIds = [];
            if ($stockList instanceof PaginatedResult) {
                foreach ($stockList->getResult() as $entry) {
                    if ($entry instanceof Stock) {
                        $variationIds[] = $entry->variationId;
                    }
                }
            }

            /** @var VariationElasticSearchSearchRepositoryContract $elasticSearchRepo */
            $elasticSearchRepo = pluginApp(VariationElasticSearchSearchRepositoryContract::class);

            /** @var DocumentProcessor $documentProcessor */
            $documentProcessor = pluginApp(DocumentProcessor::class);


            $languageMutator = pluginApp(LanguageMutator::class, ["languages" => ['de']]);
            $documentProcessor->addMutator($languageMutator);

            /** @var DocumentSearch $search */
            $search = pluginApp(DocumentSearch::class, [$documentProcessor]);

            /** @var VariationBaseFilter $variationFilter */
            $variationFilter = pluginApp(VariationBaseFilter::class);
            $variationFilter->hasIds($variationIds);

            $search->addFilter($variationFilter);

            /** @var IncludeSource $source */
            $source = pluginApp(IncludeSource::class);
            $source->activateList(
                [
                    'texts.name*',
                    'variation.number'
                ]
            );

            $search->addSource($source);

            $elasticSearchRepo->addSearch($search);
            $result = $elasticSearchRepo->execute();

            $entries = [];
            if (!empty($result['documents']) && $stockList instanceof PaginatedResult) {
                foreach ($stockList->getResult() as $entry) {
                    try {
                        if ($entry instanceof Stock) {
                            foreach ($result['documents'] as $document) {
                                if ($document['id'] == $entry->variationId) {

                                    $entries[] = $this->createStockData($sourceWarehouseId, $document, $entry);
                                }
                            }
                        }
                    } catch (\Exception $exc) {
                    }
                }
            }

            $stockList->setResult($entries);
            return $stockList;
        } catch (\Exception $exc) {
            return [
                'entries' => [],
                'firstOnPage' => 0,
                'isLastPage' => true,
                'itemsPerPage' => 25,
                'lastOnPage' => 0,
                'lastPageNumber' => 0,
                'page' => 1,
                'totalsCount' => 0
            ];
        }
    }

    /**
     * @param int $targetWarehouseId
     * @param int $sourceWarehouseId
     * @param string $searchString
     * @param int $page
     * @param int $itemsPerPage
     * @return array
     */
    public function searchStockItems($targetWarehouseId, $sourceWarehouseId, $searchString, $page, $itemsPerPage)
    {
        /** @var VariationElasticSearchSearchRepositoryContract $elasticSearchRepo */
        $elasticSearchRepo = pluginApp(VariationElasticSearchSearchRepositoryContract::class);

        /** @var DocumentProcessor $documentProcessor */
        $documentProcessor = pluginApp(DocumentProcessor::class);


        $languageMutator = pluginApp(LanguageMutator::class, ["languages" => ['de']]);
        $documentProcessor->addMutator($languageMutator);

        /** @var DocumentSearch $search */
        $search = pluginApp(DocumentSearch::class, [$documentProcessor]);
        $search->setPage($page, $itemsPerPage);

        /** @var SearchFilter $searchFilter
        $searchFilter = pluginApp(SearchFilter::class);
        $searchFilter->setNamesString($searchString, 'de');
        $search->addFilter($searchFilter);*/

        /** @var SearchFilter $searchFilter2 */
        $searchFilter2 = pluginApp(SearchFilter::class);
        $searchFilter2->setSearchString($searchString, 'de', ElasticSearch::SEARCH_TYPE_FUZZY);
        $search->addFilter($searchFilter2);


        /** @var IncludeSource $source */
        $source = pluginApp(IncludeSource::class);
        $source->activateList(
            [
                'texts.name*',
                'variation.number'
            ]
        );

        $search->addSource($source);

        $elasticSearchRepo->addSearch($search);
        $result = $elasticSearchRepo->execute();

        $entries = [];
        if (!empty($result['documents'])) {
            foreach ($result['documents'] as $document) {
                //variationId

                $this->stockRepository->clearFilters();
                $this->stockRepository->clearCriteria();
                $this->stockRepository->setFilters(
                    [
                        'variationId' => $document['id'],
                        'warehouseId' => $targetWarehouseId,
                    ]
                );

                try {
                    $stockList = $this->stockRepository->listStock(
                        ['*'],
                        1,
                        1
                    );

                    $stock = null;
                    if ($stockList instanceof PaginatedResult) {
                        $stock = $stockList->getResult()[0];
                    }

                    if ($stock instanceof Stock) {
                        $entries[] = $this->createStockData($sourceWarehouseId, $document, $stock);
                    }
                } catch (\Exception $exc) {

                }

            }
        }

        $lastPage = ceil($result['total']/$itemsPerPage);
        return [
            'entries' => $entries,
            'firstOnPage' => (($page-1)*$itemsPerPage)+1,
            'isLastPage' => $page == $lastPage,
            'itemsPerPage' => (INT)$itemsPerPage,
            'lastOnPage' => $page == $lastPage ? $result['total']  : ($page * $itemsPerPage),
            'lastPageNumber' => $lastPage,
            'page' => (INT)$page,
            'totalsCount' => $result['total']
        ];
    }

    /**
     * @param $sourceWarehouseId
     * @param $esDocument
     * @param Stock $stock
     * @return null
     */
    private function createStockData($sourceWarehouseId, $esDocument, Stock $stock)
    {
        $stockData = pluginApp(StockData::class, ['stock' => $stock]);
        if ($stockData instanceof StockData) {
            $stockData
                ->setName1($esDocument['data']['texts'][0]['name1'])
                ->setName2($esDocument['data']['texts'][0]['name2'])
                ->setName3($esDocument['data']['texts'][0]['name3'])
                ->setSelected(false)
                ->setNumber($esDocument['data']['variation']['number'])
                ->setSourceStockNet(0);

            $this->stockRepository->clearCriteria();
            $this->stockRepository->clearFilters();
            $this->stockRepository->setFilters(
                [
                    'variationId' => $stock->variationId,
                    'warehouseId' => $sourceWarehouseId
                ]
            );

            $sourceStock = $this->stockRepository->listStock(['*'], 1, 1);
            if ($sourceStock instanceof PaginatedResult) {
                $stockData->setSourceStockNet($sourceStock->getResult()[0]->stockNet);
            }

            $stockData->setRequiredStock($stock->reorderDelta);
            if ($stockData->getRequiredStock() > $stockData->getSourceStockNet()) {
                $stockData->setRequiredStock($stockData->getSourceStockNet());
            }

            return $stockData;
        }
        return null;
    }

    /**
     * @param int $targetWarehouseId
     * @param int $sourceWarehouseId
     * @param array $stockDataItems
     * @return \Plenty\Modules\Order\Models\Order
     * @throws \Exception
     */
    public function createOrder($targetWarehouseId, $sourceWarehouseId, $stockDataItems)
    {
        /** @var OrderRepositoryContract $orderRepository */
        $orderRepository = pluginApp(OrderRepositoryContract::class);

        /** @var DataBase $database */
        $database = pluginApp(DataBase::class);

        $items = [];
        foreach ($stockDataItems as $stockDataItem) {
            $items[] = [
                "typeId" => OrderItemType::TYPE_VARIATION,
                "referrerId" => 0,
                "countryVatId" => 1,
                "itemVariationId" => $stockDataItem['variationId'],
                "quantity" => $stockDataItem['orderQuantity'],
                "orderItemName" => $stockDataItem['name1'],
                "amounts" => [
                    [
                        "currency" => 'EUR',
                        "priceOriginalGross" => 0.00
                    ]
                ]
            ];
        }

        $warehouseSettings = $database->find(WarehouseSetting::class, $targetWarehouseId);
        if ($warehouseSettings instanceof WarehouseSetting) {
            /** @var ContactAddressRepositoryContract $contactAddressRepository */
            $contactAddressRepository = pluginApp(ContactAddressRepositoryContract::class);

            $settings = $warehouseSettings->settings;

            //TODO - currently not available - $address = $addressRepository->getAddressesOfWarehouse($targetWarehouseId, AddressRelationType::DELIVERY_ADDRESS)[0];
            try {
                //delivery address
                $address = $contactAddressRepository->findContactAddressByTypeId(
                    (INT)$settings['contactId'],
                    AddressRelationType::DELIVERY_ADDRESS
                );

            } catch (\Exception $exc) {
                try {
                    //fallback to billing address
                    /** @var Address $address */
                    $address = $contactAddressRepository->findContactAddressByTypeId(
                        (INT)$settings['contactId'],
                        AddressRelationType::BILLING_ADDRESS
                    );

                } catch (\Exception $exc) {
                    throw new \Exception();
                }
            }

            return $orderRepository->createOrder(
                [
                    'typeId' => OrderType::TYPE_REDISTRIBUTION,
                    'plentyId' => $this->application->getPlentyId(),
                    'statusId' => $this->configRepository->get('StockTransfer.statusCreate'),
                    'relations' => [
                        //contact
                        [
                            'referenceType' => 'contact',
                            'referenceId' => $settings['contactId'],
                            'relation' => 'receiver'
                        ]
                    ],
                    'addressRelations' => [
                        //billing
                        [
                            "typeId" => AddressRelationType::BILLING_ADDRESS,
                            "addressId" => $address->id
                        ],

                        //delivery
                        [
                            "typeId" => AddressRelationType::DELIVERY_ADDRESS,
                            "addressId" => $address->id
                        ]
                    ],
                    'properties' => [
                        //warehouse
                        [
                            'typeId' => OrderPropertyType::WAREHOUSE,
                            'subTypeId' => 1,
                            'value' => (String)$sourceWarehouseId
                        ]
                    ],
                    'orderItems' => $items
                ]
            );

        } else {
            throw new \Exception();
        }
    }

    /**
     * @param int $targetWarehouseId
     * @param int $page
     * @param int $itemsPerPage
     * @return PaginatedResult|array
     */
    public function searchOrders($targetWarehouseId, $page, $itemsPerPage)
    {
        /** @var OrderRepositoryContract $orderRepository */
        $orderRepository = pluginApp(OrderRepositoryContract::class);

        $orderRepository->clearFilters();
        $orderRepository->setFilters(
            [
                'orderType' => OrderType::TYPE_REDISTRIBUTION,
                'outgoingItemsBookedAtFrom' => '1971-00-00T00:00:00-00', //outgoing items were booked
                //'warehouseId' => $targetWarehouseId,
                'statusTo' => $this->configRepository->get('StockTransfer.statusDone')
            ]
        );

        return $orderRepository->searchOrders(
            $page,
            $itemsPerPage
        );
    }


    /**
     * @param int $orderId
     * @throws \Exception
     */
    public function intake($orderId)
    {
        /** @var OrderRepositoryContract $orderRepository */
        $orderRepository = pluginApp(OrderRepositoryContract::class);

        /** @var StockRepositoryContract $stockRepo */
        $stockRepo = pluginApp(StockRepositoryContract::class);

        try {
            $order = $orderRepository->findOrderById($orderId, ['orderItems.variation']);
            if ($order->typeId == OrderType::TYPE_REDISTRIBUTION) {

                $incomingItems = [];

                /** @var DataBase $database */
                $database          = pluginApp(DataBase::class);
                $warehouseSettings = $database->query(WarehouseSetting::class)->get();

                $warehouseId = 0;
                $contactId   = 0;

                foreach ($order->relations as $orderRelation) {
                    if ($orderRelation instanceof OrderRelationReference) {
                        if ($orderRelation->referenceType == OrderRelationReference::REFERENCE_TYPE_CONTACT) {
                            $contactId = $orderRelation->referenceId;
                            break;
                        }
                    }
                }

                if ($contactId > 0) {
                    foreach ($warehouseSettings as $warehouseSetting) {
                        if ($warehouseSetting instanceof WarehouseSetting) {
                            if (array_key_exists('contactId', $warehouseSetting->settings) && $warehouseSetting->settings['contactId'] == $contactId) {
                                $warehouseId = $warehouseSetting->warehouseId;
                                break;
                            }
                        }
                    }

                    if ($warehouseId > 0) {
                        foreach ($order->orderItems as $orderItem) {
                            if ($orderItem instanceof OrderItem) {
                                if ($orderItem->itemVariationId > 0) {
                                    $incomingItems[] = [
                                        'variationId' => $orderItem->itemVariationId,
                                        'deliveredAt' => date('c'),
                                        'currency' => 'EUR',
                                        'quantity' => $orderItem->quantity,
                                        'reasonId' => 101
                                    ];
                                }
                            }
                        }

                        $stockRepo->bookIncomingItems($warehouseId, ['incomingItems' => $incomingItems]);
                    }
                }

            } else {
                throw new \Exception('invalid order');
            }

        } catch (\Exception $exc) {
            throw new \Exception('no order found');
        }
    }
}